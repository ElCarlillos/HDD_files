
/**
 * Write a description of class LEPila here.
 * 
 * @author (AFSR & ED 7-8) 
 * @version (BETA 1.2.1xD)
 */
public class LEPila implements InterfazPila
{
    private Nodo inicio;
    private Nodo fin;

    public LEPila()
    {
        inicio = null;
        fin = null;
    }

    public void vaciarPila()
    {
        inicio = null;
        fin = null;
    }

    public boolean isEmpty()
    {
        if(inicio==null && fin==null)
        {
            return true;
        }
        return false;
    }

    public Object getTop()
    {
        if(isEmpty())
        {
            return "Vacio";
        }
        return fin.getInfo();
    }

    public boolean isFull()
    {
        return false;
    }

    public void push(Object info)
    {
        Nodo elNodo = new Nodo(info);
        if(isEmpty())
        {
            inicio = elNodo;
            fin = elNodo;
        }
        else
        {
            fin.setEnlace(elNodo);
            fin = elNodo;
        }
    }

    public Object pop()
    {
        Nodo anterior=inicio;
        Nodo eliminar = fin;
        if(isEmpty())
        {
            return "Vac�a";
        }
        else
        {
            if(anterior.getEnlace()!=null)
            {
                while(!(anterior.getEnlace().equals(fin)))
                {
                    anterior=anterior.getEnlace();
                }
                anterior.setEnlace(null);
                fin=anterior;
            }
        }
        return eliminar.getInfo();
    }
}
