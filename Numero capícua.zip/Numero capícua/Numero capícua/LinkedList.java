
import javax.swing.JOptionPane;

/**
 * Write a description of class LinkedList here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LinkedList
{
    private Nodo inicio;
    private Nodo fin;

    /**
     * Constructor for objects of class LinkedList
     */
    public LinkedList()
    {
        inicio = null;
        fin = null;
    }

    public boolean isVacia()
    {
        if(inicio == null && fin == null)
        {
            return true;
        }
        return false;
    }
        
    public void insertarAlInicio(Object info)
    {
        Nodo elNodo = new Nodo(info);
        if(isVacia())
        {
            inicio = elNodo;
            fin = elNodo;
        }
        else
        {
            elNodo.setEnlace(inicio);
            inicio = elNodo;
        }
    }
    
    public Object eliminarAlInicio()
    {
        Nodo aux=null;
        if(isVacia())
        {
            return "Vac�o";
        }
        else
        {
            aux=inicio;
            inicio=inicio.getEnlace();
            if(inicio==null)
            {
                fin=null;
            }
        }
        return aux.getInfo();
    }
    
    public Object eliminarAlFinal()
    {
        Nodo aux=null;
        Nodo sig=null;
        if(isVacia())
        {
            return "Vac�o";
        }
        else
        {
            aux=fin;
            sig=inicio;
            fin=null;
            //while(sig.getEnlace()!=fin)
            //{
                //sig=sig.getEnlace();
            //}
            do
            {
                sig=sig.getEnlace();
            }
            while(sig.getEnlace()==null);
            fin=sig;
        }
        return aux.getInfo();
    }
    
    /**
     * El m�todo insertarAlFinal crea un objeto Nodo poni�ndole como
     * informaci�n el Object que se recibe por par�metro,
     * verifica si la lista est� vac�a para
     * que el nodo insertado sea se�alado por la referencia inicio
     * y la referencia fin, de lo contrario, para insertar el nodo se
     * asigna la direcci�n del nuevo nodo al enlace del nodo fin y se
     * actualiza la referencia fin.
     * 
     * @param - info que es un Object y representa la infromaci�n que 
     * se almacenar� en el nodo a insertar.
     */
    public void insertarAlFinal(Object info)
    {
        Nodo elNodo = new Nodo(info);
        if(isVacia())
        {
            inicio = elNodo;
            fin = elNodo;
        }
        else
        {
            fin.setEnlace(elNodo);
            fin = elNodo;
        }
    }
    
    /**
     * 
     */
    public Object getInicio()
    {
        if(isVacia())
        {
            return "Vacio";
        }
        return inicio.getInfo();
    }
    
    /**
     * 
     */
    public Object getFinal()
    {
        if(isVacia())
        {
            return "Vacio";
        }
        return fin.getInfo();
    }
    
    public Object extract(Object item)
    {
        Nodo ptr = inicio;
        Nodo prevPtr = null;
        Object variable = null;
        while(ptr != null && !(ptr.getInfo().equals(item)))
        {
            prevPtr = ptr;
            ptr = ptr.getEnlace();
        }
        if(ptr==null)
        {
            throw new IllegalArgumentException ("Objeto no encontrado.");
        }
        if(ptr==inicio)
        {
            inicio = ptr.getEnlace();
            variable = ptr.getInfo();
        }
        else
        {
            variable = ptr.getInfo();
            prevPtr.setEnlace(ptr.getEnlace());
        }
        if(ptr==fin)
        {
            fin = prevPtr;
        }
        return variable;
    }
    
    public void copiar(LinkedList lista)
    {
        if(lista!=this)
        {
            eliminarTodo();
            for(Nodo ptr=lista.inicio;ptr!=null; ptr = ptr.getEnlace())
            {
                insertarAlFinal(ptr.getInfo());
            }
        }
    }
    
    public void eliminarTodo()
    {
        inicio = null;
        fin = null;
    }
    
    public String toString()
    {
        String salida = "";
        Nodo sig = inicio;
        while (sig !=null)
        {
            salida = salida + sig.getInfo().toString() + "\n";
            sig = sig.getEnlace();
        }
        return salida;
    }
    
    //public static void main(String[]args)
    //{
    //    LinkedList lista = new LinkedList();
    //    lista.insertarAlInicio(4);
    //    lista.insertarAlInicio(8);
    //    lista.insertarAlInicio(12);
    //    lista.insertarAlInicio(16);
    //    lista.insertarAlFinal(100);
    //    lista.insertarAlFinal(200);
    //    JOptionPane.showMessageDialog(null, lista.toString());
    //}
}
