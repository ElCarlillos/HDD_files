
import javax.swing.JOptionPane;

/**
 * Write a description of class NumCapicua here.
 * 
 * @author (AFSR & ED 7-8) 
 * @version (BETA 1.2.1xD)
 */
public class NumCapicua
{
    boolean continuar = false;
    static String cadenaEntrada = "";
    LEPila pila = new LEPila();
    LECola cola = new LECola();
    public void insertarElementos()
    {
        do
        {
            try
            {
                continuar = false;
                cadenaEntrada = JOptionPane.showInputDialog("Ingresa un n�mero.");
                for(int indice=0; indice<cadenaEntrada.length();indice++)
                {
                    if(!Character.isDigit(cadenaEntrada.charAt(indice)))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        pila.push(cadenaEntrada.charAt(indice));
                        cola.encolar(cadenaEntrada.charAt(indice));
                    }
                }
            }
            catch (Exception e)
            {
                JOptionPane.showMessageDialog(null, "Ingrese s�lo d�gitos.");
                continuar = true;
            }
        }while (continuar);
    }

    public void comparar()
    {
        String op1 = "";
        String op2 = "";
        while(!cola.isVacio()&&!pila.isEmpty())
        {
            op1 += cola.desencolar();
            op2 += pila.pop();
            if(op1.equals(op2))
            {

            }
            else
            {
                JOptionPane.showMessageDialog(null, cadenaEntrada + " no es un n�mero capic�a.");
                break;
            }
        }
        if(cola.isVacio())
        {
            JOptionPane.showMessageDialog(null, cadenaEntrada + " si es un n�mero cap�cua.");
        }
    }

    public static void main (String [] arg)
    {
        int next = 0;
        do
        {
            NumCapicua act = new NumCapicua();
            act.insertarElementos();
            act.comparar();
            next = JOptionPane.showConfirmDialog(null, "Quieres intentar de nuevo? ",
                "Confirmar captura.",
                JOptionPane.YES_NO_OPTION);
        }while(next == 0);
    }
}
