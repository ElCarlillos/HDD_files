import javax.swing.JOptionPane;

/**
 * Write a description of class LECola here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LECola implements ICola
{
    private Nodo inicio;
    private Nodo fin;

    /**
     * Constructor de objetos de la clase Cola sin atributos ni par�metros con un arreglo que toma un valor inicial de 20,
     * las variables frente y fin que toman el valor de -1.
     */
    public LECola()
    {
        inicio = null;
        fin = null;
    }

    public void vaciarCola()
    {
        inicio = null;
        fin = null;
    }

    /**
     * M�todo de la clase Cola cuyo fin es verificar si el objeto Cola est� vac�o, en caso de ser correcto devuelve true,
     * de lo contrario devuelve un false
     * 
     * @return boolean
     */
    public boolean isVacio()
    {
        if(inicio==null && fin==null)
        {
            return true;
        }
        return false;
    }

    /**
     * M�todo de la clase Cola que devuelve true si el objeto Cola est� lleno, de lo contrario devuelve un false.
     * 
     * @return boolean
     */
    public boolean isLleno()
    {
        return false;
    }

    /**
     * M�todo de la clase Cola que permite insertar un elemento por un extremo del objeto Cola.
     * 
     * @param - obj de tipo Object que es el elemento a insertar.
     */
    public void encolar(Object info)
    {
        Nodo elNodo = new Nodo(info);
        if(isVacio())
        {
            inicio = elNodo;
            fin = elNodo;
        }
        else
        {
            fin.setEnlace(elNodo);
            fin = elNodo;
        }
    }

    /**
     * M�todo de la clase Cola que permite extraer por el otro extremo el primero de los elementos insertados.
     * 
     * @return Object
     */
    public Object desencolar()
    {
        Nodo aux=null;
        if(isVacio())
        {
            return "Vac�o";
        }
        else
        {
            aux=inicio;
            inicio=inicio.getEnlace();
            if(inicio==null)
            {
                fin=null;
            }
        }
        return aux.getInfo();
    }

    /**
     * M�todo de la clase Cola que muestra el primer elemento insertado.
     * 
     * @return Object
     */
    public Object getFrente()
    {
        if(isVacio())
        {
            return "Vacio";
        }
        return inicio.getInfo();
    }

    /**
     * M�todo de la clase Cola que muestra el �ltimo elemento insertado.
     * 
     * @return Object
     */
    public Object getFondo()
    {
        if(isVacio())
        {
            return "Vacio";
        }
        return fin.getInfo();
    }
}