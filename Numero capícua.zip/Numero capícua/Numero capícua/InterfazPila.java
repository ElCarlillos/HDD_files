

/**
 * Write a description of interface InterfazPila here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface InterfazPila
{
    /**
     * El m�todo push debe insertar un elemento en la siguiente posici�n de la pila,
     * siempre que la pila no est� llena.
     * 
     * @param  Object - El elemento a insertar en la pila.
     */
    void push(Object ob);
    
    /**
     * El m�todo pop debe extraer el siguiente elemento de la pila (el del tope),
     * siempre que la pila no est� vac�a.
     * @return Object - El elemento que se extrae del tope de la pila.
     */
    Object pop();
    
    /**
     * El m�todo isEmpty nos permite verificar si la pila est� vac�a.
     * @retun boolean - true si la pila est� vac�a, de lo contrario regresa false.
     */
    boolean isEmpty();
    
    /**
     * El m�todo isFull nos permite verificar si la pila est� llena.
     * @return boolean - true si la pila est� llena, de lo contrario regresa false.
     */
    boolean isFull();
    
    /**
     * El m�todo getTop nos permite obtener el elemento del tope de la pila sin sacarlo.
     * @return Object - El objeto que se encuentra a�n en el tope de la pila.
     */
    Object getTop();
}
