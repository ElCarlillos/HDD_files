/**
 * Write a description of interface ICola here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface ICola extends IContenedor
{
    /**
     * 
     */
    Object getFrente();
    
    /**
     * 
     */
    Object getFondo();
    
    /**
     * 
     */
    void encolar(Object obj);
    
    /**
     * 
     */
    Object desencolar();
}
