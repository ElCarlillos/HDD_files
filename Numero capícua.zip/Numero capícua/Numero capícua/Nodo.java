
import javax.swing.JOptionPane;

/**
 * Write a description of class Nodo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nodo
{
    private Object info;
    private Nodo enlace;
    
    public Nodo(Object info)
    {
        this.info = info;
        this.enlace = null;
    }
    
    public void setInfo(Object info)
    {
        this.info = info;
    }
    
    public Object getInfo()
    {
        return info;
    }
    
    public void setEnlace(Nodo enlace)
    {
        this.enlace = enlace;
    }
    
    public Nodo getEnlace()
    {
        return enlace;
    }
    
    /**
     * Regresa la informaci�n <info> del nodo
     */
    public String toString()
    {
        return "\n Nodo \nInformaci�n: " + info;// + "\n Enlace: " + enlace;
        //Versi�n final no se imprime el enlace
    }
    
    public static void main (String [] nodo)
    {
        //Autounboxing
        Nodo n1 = new Nodo(3);
        //Unboxing = Nodo n1 = new Nodo(new Integer (3))
        JOptionPane.showMessageDialog(null, n1);
        Nodo n2 = new Nodo(4);
        n1.setEnlace(n2);
        JOptionPane.showMessageDialog(null, n1);

        Nodo n3 = new Nodo(5);
        n2.setEnlace(n3);
        JOptionPane.showMessageDialog(null, n1);
    }
}
