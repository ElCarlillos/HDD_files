
/**
 * Write a description of class EdadException here.
 * 
 * @author CAVH
 * @version 17/02/2014
 */
public class EdadException extends Exception
{
    
}
