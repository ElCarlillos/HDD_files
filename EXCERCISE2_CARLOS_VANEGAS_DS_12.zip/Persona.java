
/**
 * Write a description of class Persona here.
 * 
 * @author CAVH
 * @version 17/02/2014
 */
public class Persona
{
    // instance variables - replace the example below with your own
    private String name;
    private String surname;
    private String maidenName;
    private int age;

    /**
     * Constructor for objects of class Persona that receives all the
     * Persona info by parameter and assigns it to the attributes.
     * In the age assignment, if the age received by parameter is 
     * out of the range 1 and 100 inclusive, it is propagated an
     * EdadException object.
     */
    public Persona(String n, String surn, String mn, int age)throws EdadException
    {
       name = n;
       surname = surn;
       maidenName = mn;
       if(age < 1 || age > 101)
       {
           throw new EdadException();
       }
       if( !(age < 1 || age > 101) )
       {
           this.age = age;
       }
    }

    /**
     * Setters and getters
     */
    public void setName(String n)
    {
        name = n;
    }
    
    public void setSurname(String sr)
    {
        surname = sr;   
    }
    
    public void setMn(String mn)
    {
        maidenName = mn;
    }
    
    public void setAge(int age)throws EdadException
    {
        if(age < 1 || age > 101)
       {
           throw new EdadException();
       }
       if( !(age < 1 || age > 101) )
       {
           this.age = age;
       }
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getSurname()
    {
        return surname;
    }
    
    public String getMn()
    {
        return maidenName;
    }
    
    public int getAge()
    {
        return age;
    }
    
    public String toString()
    {
        return "The person�s information is:" + "\n" +
               "\nName:" + "  " + name +
               "\nSurname:" + "  " + surname + 
               "\nMaiden name:" + "  " + maidenName + 
               "\nAge:" + "  " + age + "\n";
    }
    
    public boolean equals(Object obj)
    {
        if(obj != null)
        {
            if(obj instanceof Persona)
            {
                Persona p = (Persona)obj;
                if(this.name.equals(p.name) &&
                   this.surname.equals(p.surname) &&
                   this.maidenName.equals(p.maidenName) &&
                   this.age == p.age)
                {
                    return true;
                }
            }
        }
        return false;
    }
}
