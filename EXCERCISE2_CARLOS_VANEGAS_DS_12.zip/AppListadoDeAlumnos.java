import javax.swing.JOptionPane;
import java.lang.*;
/**
 * Write a description of class AppListadoDeAlumnos here.
 * 
 * @author CAVH :) xD
 * @version 20/02/2014 
 */
public class AppListadoDeAlumnos
{
    private Alumno[] list;

    /**
     * Constructor for objects of class AppListadoDeAlumnos
     */
    public AppListadoDeAlumnos(int n)
    {
        // initialise instance variables
        list = new Alumno[n];
    }

    /**
     * Method to create as many Alumno objects as the user wants to
     * and insert each one in the array. Also this method have a cycle to,
     * in each of the objects, insert as many subjects as he wants.
     * 
     */
    public void crearAlumnos()
    {
        //Here you start a cycle to construct as many objects as the user wants
        int opList = 0;
        do{
            //Ask for the Alumno info to can build the object
            String name = JOptionPane.showInputDialog("Name of the student?");
            String surname = JOptionPane.showInputDialog("His/Her surname?");
            String maidenName = JOptionPane.showInputDialog("His/Her maiden name?");
            int a = Integer.parseInt(JOptionPane.showInputDialog("His/her age?"));
            int i = 0;
            int cSubjects = 0;
            for(;i<list.length;i++)
            {
                if(list[i] == null)
                {
                    break;
                }
            }
            //Here we catch the EdadException, because is in the call to the
            //Alumno constructor when the exception is produced
            try{
                list[i] = new Alumno(name, surname, maidenName, a);
            }catch(EdadException ee)
            {
                while(a < 1 || a > 101)
                {
                    JOptionPane.showMessageDialog(null, "The age is invalid, type it again please");
                    a = Integer.parseInt(JOptionPane.showInputDialog("His/her age?"));
                }
            }
            /**
             *Here, with the object inserted to the array, you ask to the user
             *the info of a Asignatura object to insert into the Alumno object inserted
             *on the array. It should be till the user says no.
             */
            //Starts do(for do it till the user says no more Asignatura�s)
            
            do{
                
                
                //Here you ask if the user wants to continue adding 
                //subjects to the student
                   list[i].agregarAsignatura();
                cSubjects = JOptionPane.showConfirmDialog(null,
                                           "Do you want continue adding subjects?",
                                     "Add option entrance",
                                     JOptionPane.YES_NO_OPTION);
            }while(cSubjects == 0);
            //Here, at the end you ask the user if he wants to continue
            //adding Alumno objects to the array
            opList = JOptionPane.showConfirmDialog(null,
                                     "Do you want continue adding students?",
                                     "Add option entrance",
                                     JOptionPane.YES_NO_OPTION);
        }while(opList == 0);
    }
    
    public String toString()
    {
        String var = "";
        int ind = 0;
        int index = 0;
       for(;index<list.length;index++)
       {
            if(list[index] != null)
            {
                var = var +  list[index].toString() + "\n";
                //System.out.println(var);
                
                
            }
            
            
        }
        return var;
    }
    
    public static void main(String[] rock)
    {
        AppListadoDeAlumnos obj = new AppListadoDeAlumnos(10);
        obj.crearAlumnos();
        JOptionPane.showMessageDialog(null, obj.toString());
    }
}
