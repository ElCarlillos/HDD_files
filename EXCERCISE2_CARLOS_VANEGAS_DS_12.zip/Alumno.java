import javax.swing.JOptionPane;
/**
 * Write a description of class Alumno here.
 * 
 * @author CAVH 
 * @version 20/02/2014
 */
public class Alumno extends Persona
{
   private Asignatura[] subjects;
   
   public Alumno(String n, String sr, String mn, int a)throws EdadException
   {
       super(n,sr,mn,a);
       subjects = new Asignatura[60];
   }
   
   public double calcularPromedio()
   {
       double result = 0;
       for(int i = 0;i<this.subjects.length;i++)
       {
           if(this.subjects[i] != null)
           {
               result = result + this.subjects[i].getNote();
           }
       }
       return result;
   }
   
   public void agregarAsignatura()
   {
       int i = 0;
       String sub_name = JOptionPane.showInputDialog("Wich is the subject�s name");
                
       double sub_note = MyUtils.readDouble("Wich is the subject�s note?");   
       int ind = 0;
       Asignatura oneAsignatura = new Asignatura(sub_note,sub_name);
       for(;i<this.subjects.length;i++)
       {
           if(this.getAsignatura()[ind] == null)
           {
               if(this.subjects[i] != oneAsignatura)
               {
               
                  
                        break;
                    
                }
            }
       }

                   this.subjects[i] = oneAsignatura;
       //list[i].getAsignatura()[ind] = new Asignatura(sub_note,sub_name);    
       
                
                    
                    
                
                
   }
   
   public String toString()
   {
       String aux = super.toString() + "COURSED SUBJECTS" + "\n";
       for(int i = 0;i<this.subjects.length;i++)
       {
           if(this.subjects[i] != null)
           {
               
               aux = aux  + this.subjects[i].toString() + "\n";
           }
       }
       return aux;
   }
   
   public Asignatura[] getAsignatura()
   {
        return subjects;    
   }
}
