
/**
 * Write a description of class Asignatura here.
 * 
 * @author CAVH
 * @version 17/02/2014
 */
public class Asignatura
{
    // instance variables - replace the example below with your own
    private double note;
    private String name;

    /**
     * Constructor for objects of class Asignatura
     * that receives all the data by parameter
     */
    public Asignatura(double note,String name)
    {
        this.note = note;
        this.name = name;
    }

    /**
     * Getters and Setters
     */
    public void setName(String name)
    {
        this.name = name;
    }

    public void setNote(double note)
    {
        this.note = note;
    }

    public String getName()
    {
        return name;
    }

    public double getNote()
    {
        return note;
    }

    public String toString()
    {
        return 
        name + "  " + note + "  " + getResult() + "\n";
    }

    public boolean equals(Object obj)
    {
        if(obj != null)
        {
            if(obj instanceof Asignatura)
            {
                Asignatura a = (Asignatura)obj;
                if(this.name.equals(a.name) &&
                this.note == a.note )
                {
                    return true;
                }
            }
        }
        return false;
    }

    public String getResult()
    {
        if(note > 0 && note < 101)
        {
            if(note >= 70)
            {
                return "APPROVED";
            }

            if(note < 70)
            {
                return "FAIL";
            }
        }

        return "The value is not valid";

    }
}
