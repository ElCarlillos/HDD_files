import javax.swing.JOptionPane;
/**
 * Write a description of class MyUtils here.
 * 
 * @author CAVH
 * @version 27/2/2014
 */
public class MyUtils
{
    /**
     * Method to validate decimal numeric entrance
     * This method read a double value at a showInputDialog
     * till the readed value is a valid double
     * 
     * @param String - The message to show in the dialog
     * @return double - A right double value reded
     */
    public static double readDouble(String msg)
    {
        double value = 0.0;
        boolean still = false;
        do{
            try{
                //Block of sentences that will be executed under supervision
                //to seek for a NumberFormatException instance
                still = false;
                String str = JOptionPane.showInputDialog(msg);
                value = Double.parseDouble(str);
            }catch(NumberFormatException nfe)
            {
                JOptionPane.showMessageDialog(null, 
                                    "You must type only decimal numbers");
                still = true;
            }
        }while(still);
        return value;
    }
}
