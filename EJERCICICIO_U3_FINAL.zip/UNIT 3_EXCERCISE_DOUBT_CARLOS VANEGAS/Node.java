//package unidt3;


/**
 * Write a description of class Nodo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Node
{
    private Object info;
    private Node link;
    
    /**
     * Constructor for Node objects. This constructor ask for an Object parameter
     * that will be the info of the Node. Then it initializes the link of the Node in null
     * , because initially the node are not linked to any other node.
     * @param - Object - The info inside the node
     */
    public Node(Object newinfo)
    {
        info = newinfo;
        link = null;
    }
    
    /**
     * This methods let us modify the info of the node
     * @param - Object - The new info of the node
     */
    public void setInfo(Object newInfo)
    {
        info = newInfo;
    }
    
    /**
     * This method set the Link to the next Node inside the 
     * LinkedList
     * @param - Node - A reference to the next node
     */
    public void setLink(Node newLink)
    {
        link = newLink;
    }
    
    /**
     * This method returns us the info of the Node, without
     * taking it out of the Node.
     * @return Object - The info of the node
     */
    public Object getInfo()
    {
        return info;
    }
    
    /**
     * This method returns the reference to the next node.
     * @return  - Node - A reference to the next node
     */
    public Node getLink()
    {
        return link;
    }
    
    /**
     * The toString method returns the information of the
     * node, in a formatted String
     * @return - String - All the node info
     */
    public String toString()
    {       
        if(info != null )
        {     
            String cadena = info.toString();
            return cadena;
        }
        return  "Ther is no node!!";
        
    }
    
    
}