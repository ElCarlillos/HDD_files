//package unidt3;

import javax.swing.JOptionPane;
//import unidad2.iQueue;
/**
 * Write a description of class QueueAsLinkedList here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class QueueAsLinkedList //implements iQueue
{
   private LinkedList list;
   private int count;
   
   public QueueAsLinkedList()
   {
       list = new LinkedList();
       count = 0;
   }
   
   public boolean isEmpty()
   {
       return list.isEmpty();
   }
   
   public Object getFront()
   {
       if(count == 0)
       {
           JOptionPane.showMessageDialog(null, "The queue is empty!!!");           
       }
       return list.getHead();
   }
   
   public Object getRear()
   {
       if(isEmpty())
       {
          JOptionPane.showMessageDialog(null, "The queue is empty!!!"); 
       }
       return list.getTail();
   }
   
   public void enqueue(Object obj)
   {
       list.insertAtTail(obj);
       count++;
   }
   
   public boolean isFull()
   {
       return false;
   }
   
   public Object dequeue()
   {
       Object result = null;
       if(count == 0)
       {
           JOptionPane.showMessageDialog(null, "THE QUEUE IS EMPTY!!!!!");
       }
       else
       {
           result = list.deleteFirst();
           count--;
       }
       return result;
   }
   
   public int getCount()
   {
       return count;
   }
   
   public void purge()
   {
       list.purge();
   }
}
