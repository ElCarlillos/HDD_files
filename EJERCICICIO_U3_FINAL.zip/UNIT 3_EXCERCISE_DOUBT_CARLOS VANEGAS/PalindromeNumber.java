//package unidt3;
//import unidad2.*;
import javax.swing.JOptionPane;
/**
 * The PalindromeNumber class ask for an string maked by
 * digits, and checks if the number readed is a palindrome 
 * number or not. The palindrome numbers are those that
 * are readed equal from the right than from the left.
 * 
 * @author CAVH
 * @version 7/05/2014
 */
public class PalindromeNumber
{
    private static String number;    
    static StackAsLinkedList stack = new StackAsLinkedList();
    static QueueAsLinkedList queue = new QueueAsLinkedList();
    /**
     * This method ask for a string of digits, and checks if the
     * readed number is a palindrome.
     * @param - String - The number to check
     */
    public static void checkNumber()
    {
        int op = 0;
        boolean flag;
        do{
            number = JOptionPane.showInputDialog("Type a number to check please");
            for(int i = 0;i<number.length();i++)
            {
                stack.push(Character.digit(number.charAt(i), 10));
                queue.enqueue(Character.digit(number.charAt(i), 10));
            }
            String out = "";   
            //Object digit1 = stack.pop();
            //Object digit2 = queue.dequeue();
            flag = true;
            while(!stack.isEmpty() && !queue.isEmpty())
            {           
                if( ! stack.pop().equals(queue.dequeue()) )
                {
                    flag = false;
                    stack.purge();
                    queue.purge();
                }
            }      
            if(flag == true)
            {
                
                JOptionPane.showMessageDialog(null, "THE NUMBER" + "  " + number + 
                    "IS A PALINDROME");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "THE NUMBER" + "  " + number + 
                    "IS NOT A PALINDROME");
            }

            op = JOptionPane.showConfirmDialog(null, 
                "Continue checking...?",
                "Continue entrance",
                JOptionPane.YES_NO_OPTION
            );
        }while(op==0);
    }

    public static void main(String[] args)
    {
        
        PalindromeNumber pn = new PalindromeNumber();
        pn.checkNumber();
    }
}

