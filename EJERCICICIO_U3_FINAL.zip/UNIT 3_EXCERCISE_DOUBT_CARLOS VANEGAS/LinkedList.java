//package unidt3;
import javax.swing.JOptionPane;

/**
 * Write a description of class LinkedList here.
 * 
 * @author CAVH
 * @version 06/05/2014
 */
public class LinkedList
{
    // instance variables - replace the example below with your own
    private Node head;
    private Node tail;
 

    
    /**
     * This method is an empty constructor for LinkedList, 
     * wich initialize the head and tail attributes in null,
     * in order to represent an empty LinkedList
     */
    public LinkedList()
    {
       head = null;
       tail = null;
    }
    
    
    /**
     * The isEmpty method allows us to know if the 
     * linkedList is empty or not
     * @return - boolean - True - LinkedList is empty, 
     *                     false is not empty
     */
    public boolean isEmpty()
    {
        if(head == null && tail == null)
        {
            return true;
        }
        return false;
    }
    
    /**
     * This method let us know if the LinkedList is full.
     * As a linkedList is allocated in dynamic memory, the
     * method always returns a false.
     */
    public boolean isFull()
    {
        return false;
    }
    
    public void extract(Object item)
    {
        Node ptr = head;
        Node prevPtr = null;        
        while( ptr != null && ptr.getInfo() != item)     
        {
            prevPtr = ptr;
            ptr = ptr.getLink();
        }
        if(ptr == null)
        {
            throw new IllegalArgumentException(
                        "Item not found");
                    
        }
        if(ptr == head)
        {
            head = ptr.getLink();
        }
        else
        {
            prevPtr.setLink(ptr.getLink());
        }
        if(ptr == tail)
        {
            tail = prevPtr;
        }
    }
    
    /**
     * This method insert a Node at the front of the LinkedList
     * , wich is the head references. The methods ask for an object
     * parameter, with this parameter, it creates a node to insert in
     * the linkedList
     * @param - Object o - The object to insert at head
     */    
    public void insertAtHead(Object o)
    {
        Node newNode = new Node(o);
        if(!isEmpty())
        {
           newNode.setLink(head);
           head = newNode;                      
        }         
        else
        {
            head= newNode;     
            tail = newNode;
        }
    }
    
    /**
     * This method is similar to the insertAtHead one, the diference
     * is that this method insert the node at the tail of the 
     * LinkedList
     * @param - Object - The object to insert
     */
    public void insertAtTail(Object obj)
    {
        Node newNode = new Node(obj);
        if(isEmpty())
        {
            head = newNode;
            tail = newNode;
        }        
        else
        {
            tail.setLink(newNode);
            tail = newNode;                        
        }
        JOptionPane.showMessageDialog(null, head);
        JOptionPane.showMessageDialog(null, tail
        );
    }
    
    /**
     * The deleteFirst method attempt to delete the head element 
     * at the LinkedList, then the method returns the data
     * of the deleted element.
     * @return - Node - The node that was deleted.
     */
    public Object deleteFirst()
    {
        Node auxNode = head;
        if(!isEmpty())
        {
            if(head == tail)
            {
                head = null;
                tail = null;
            }
            if(head != tail)
            {                
                head = head.getLink();
                
            }
            return auxNode.getInfo();
        }
        else
        {
            return "Empty list";
        }
    }
    
    public Object deleteLast()
    {
        if(isEmpty())
        {
            return "Lista vacia";
        }        
        else
        {
            Object aux;
            aux = tail.getInfo();
            Node next = head;
            while(head.getLink() != tail)
            {
                next = next.getLink();
            }
            next.setLink(null);
            tail = next;
            return aux;
        }
    }
    
    /**
     * 
     * The getHead method just return the head element
     * in the LinkedList
     * @return - Node - The head element in the LinkedList
     */
    public Node getHead()
    {   return head;
        
    }
    
    /**
     * The getTail method returns the tial element.
     * 
     * @return - Object - The last element
     */
    public Node getTail()
    {
        return tail;
    }
    
    public void purge()
    {
        head = null;
        tail = null;
    }
    
    /**
     * The toString returns a formatted String with the data
     * of all the elements(Nodes) in the LinkedList
     */
    public String toString()
    {
        String output = "";
        Node actualNode = head;        
        
        while(actualNode != null)
        {
            output += actualNode.toString() + "\n";
            actualNode = actualNode.getLink();
            
        }
        
        return output;
    }
    
    public static void main(String[] args)
    {
        LinkedList list = new LinkedList();
        list.insertAtHead(1);
        list.insertAtHead(2);
        list.insertAtHead(3);
        list.insertAtHead(4);
        list.insertAtHead(5);
        JOptionPane.showMessageDialog(null, "TO STRING METHOD CALL:" + "\n" +
                        list.toString());
    }  
}
