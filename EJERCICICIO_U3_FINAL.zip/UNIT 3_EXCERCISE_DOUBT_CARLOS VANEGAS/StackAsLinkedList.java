//package unidt3;

//package unidt3;
import javax.swing.JOptionPane;

/**
 * Write a description of class StackAsLinkedList here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StackAsLinkedList
{
    protected LinkedList list;
    private int count;
    /**
     * Constructor for objects of class StackAsLinkedList
     */
    public StackAsLinkedList()
    {
        list = new LinkedList();
        count = 0;
    }

    public void push(Object obj)
    {

        list.insertAtHead(obj);
        count++;
    }

    public Object pop()
    {
        Object result = null;
        if(!list.isEmpty())
        {    
            result = list.deleteFirst();
            count--;
        }
        else
        {
            JOptionPane.showMessageDialog(null, "YOUR STACK IS EMPTY!!!");
        }
        return result;
    }

    public boolean isEmpty()
    {
        return list.isEmpty();
    }

    public int getCount()
    {
        return count;
    }

    public void purge()
    {
        list.purge();
    }
    
}
